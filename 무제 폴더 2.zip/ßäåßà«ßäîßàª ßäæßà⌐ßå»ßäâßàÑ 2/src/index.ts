import { Game } from "./game";
import { GameManagerConfig } from "./GameManager";
import Scene_start from "./Scene_Start";




new Game(new GameManagerConfig()
    .setBackgounrColor(0)
    .setDefaultScene(new Scene_start)

)

//const message : string = "hello world"
//console.log(message)