import * as PIXI from 'pixi.js'
import { Component, ComponentBuilder } from './Component';
import * as PUXI from './puxi'
import { UIScene } from './UIScene';



export abstract class GameManager{
    private currentScene : UIScene | null = null;
    private _canvasForScene : Component;
    private _ustage: PUXI.Stage;
    private _configuration: GameManagerConfig;
    private _app : PIXI.Application
    private _prevTime: number = Date.now();
    private _currentScene : UIScene | null = null;

    constructor(configuration: GameManagerConfig) {
        this._configuration = configuration;

        this._app = new PIXI.Application({
            //width: 800, height: 600,
            //resolution: window.devicePixelRatio || 1,
        });
        this._app.renderer.view.style.position = "absolute";
        this._app.renderer.view.style.display = "block";
        document.body.appendChild(this._app.view);

        // stage
        this._ustage = new PUXI.Stage();
        this._app.stage.addChild(this._ustage);
        this._app.renderer.backgroundColor = configuration.backgroundColor;

        // canvas
        let canvasBuilder = new ComponentBuilder()
            .setFit()
            .addTo(this._ustage);
        this._canvasForScene = canvasBuilder.Instantiate();

        // let a= new PUXI.Sprite(PIXI.Texture.WHITE);
        // a.width = 100
        // a.height = 100
        // this._canvasForScene.addChild(a);

        let ticker = new PIXI.Ticker();
        ticker.add(()=>{
            let now = Date.now();
            let dt = (now - this._prevTime) * 0.001;

            this.onEnterFrame(dt);
            if (this._currentScene != null) {
                this._currentScene.enterFrame(dt);
            }

        });

        ticker.start();
        this.resize();

        this.onInit();

        if (this._configuration.initialScene != null) {
            this.setScene(this._configuration.initialScene);
        }
    }

    public setScene(scene: UIScene) {
        if (this._currentScene != null) {
            this._currentScene.destroy();
        }

        scene.width = "100%";
        scene.height = "100%";
        this._canvasForScene.addChild(scene);
        this._currentScene = scene;

        // let a= new PUXI.Sprite(PIXI.Texture.WHITE);
        // a.width = 100
        // a.height = 100
        // this._canvasForScene.addChild(a);
        this.resize();
    }


    private resize() {
        const w = document.documentElement.clientWidth;
        const h = document.documentElement.clientHeight;
        this._app.renderer.resize(w, h);
        this._ustage.resize(w, h);

        if (this._currentScene != null) {
            // this._configuration.resolutionResolver?.resolve(this._canvasForScene, w, h);
            // this._configuration.resolutionResolver?.resolve(this._canvasForPopup, w, h);
            // this._configuration.resolutionResolver?.resolve(this._canvasForOver,  w, h);
        }
    }
    protected abstract onInit(): void;
    protected abstract onEnterFrame(dt: number) :void;
}


export class GameManagerConfig {
    private _backgroundcolor : number = 0xffffff;
    private _initialScene : UIScene | null = null;


    constructor() {}
    public get backgroundColor(): number { return this._backgroundcolor;}
    public get initialScene(): UIScene | null { return this._initialScene; }


    public setDefaultScene(scene: UIScene): this {
        this._initialScene = scene;
        return this;
    }

    public setBackgounrColor(color: number): this {
        this._backgroundcolor = color;
        return this;
    }
}

