
// var Library = {
//     UI: require('./UI')
// };

// //dump everything into extras

// Object.assign(PIXI, Library);

// module.exports = Library;


// var Lib = { UI: {
//     Stage: require('./Stage'),
//     Container: require('./Container'),
//     ScrollingContainer: require('./ScrollingContainer'),
//     SortableList: require('./SortableList'),
//     Sprite: require('./Sprite'),
//     TilingSprite: require('./TilingSprite'),
//     SliceSprite: require('./SliceSprite'),
//     Slider: require('./Slider'),
//     ScrollBar: require('./ScrollBar'),
//     Text: require('./Text'),
//     DynamicText: require('./DynamicText/DynamicText'),
//     DynamicTextStyle: require('./DynamicText/DynamicTextStyle'),
//     TextInput: require('./TextInput'),
//     Button: require('./Button'),
//     CheckBox: require('./CheckBox'),
//     Helpers: require('./Helpers'),
//     Tween: require('./Tween'),
//     Ease: require('./Ease/Ease'),
//     Interaction: require('./Interaction/Interaction'),
//     Base: require('./UIBase'),
//     Ticker: require('./Ticker').shared,
// } };


// module.exports = Lib;

import Stage from './Stage';
import Container from './Container';
import ScrollingContainer from './ScrollingContainer';
import SortableList from './SortableList';
import Sprite from './Sprite';
import TilingSprite from './TilingSprite';
import SliceSprite from './SliceSprite';
import Slider from './Slider';
import ScrollBar from './ScrollBar';
import Text from './Text';
import DynamicText from './DynamicText/DynamicText';
import DynamicTextStyle from './DynamicText/DynamicTextStyle';
import TextInput from './TextInput';
import Button from './Button';
import CheckBox from './CheckBox';
import Helpers from './Helpers';
import Tween from './Tween';
import Ease from './Ease/Ease';
import Interaction from './Interaction/Interaction';
import Base from './UIBase';
import _Ticker from './Ticker';
import DragContainer from './Ext/DragContainer';

const Ticker = _Ticker.shared;

export { Stage, Container, ScrollingContainer, SortableList, Sprite, TilingSprite, SliceSprite, Slider, ScrollBar, Text, DynamicText, DynamicTextStyle, TextInput, Button, CheckBox, Helpers, Tween, Ease, Interaction, Base, Ticker, DragContainer };