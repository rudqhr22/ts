﻿var MouseScrollEvent = function (obj, preventDefault)
{
    var bound = false, delta = new PIXI.Point(), self = this;
    obj.container.interactive = true;

    var _onMouseScroll = function (event)
    {
        if (preventDefault)
            event.preventDefault();

        if (typeof event.deltaX !== "undefined")
            delta.set(event.deltaX, event.deltaY);
        else //Firefox
            delta.set(event.axis == 1 ? event.detail * 60 : 0, event.axis == 2 ? event.detail * 60 : 0);

        self.onMouseScroll.call(obj, event, delta);
    };

    var _onHover = function (event)
    {
        if (!bound)
        {
            document.addEventListener("mousewheel", _onMouseScroll, { passive: false });
            document.addEventListener("DOMMouseScroll", _onMouseScroll, { passive: false });
            bound = true;
        }
    };

    var _onMouseOut = function (event)
    {
        if (bound)
        {
            document.removeEventListener("mousewheel", _onMouseScroll, { passive: false });
            document.removeEventListener("DOMMouseScroll", _onMouseScroll, { passive: false });
            bound = false;
        }
    };

    this.stopEvent = function ()
    {
        if (bound)
        {
            document.removeEventListener("mousewheel", _onMouseScroll, { passive: false });
            document.removeEventListener("DOMMouseScroll", _onMouseScroll, { passive: false });
            bound = false;
        }
        obj.container.removeListener('mouseover', _onHover);
        obj.container.removeListener('mouseout', _onMouseOut);
    };

    this.startEvent = function ()
    {
        obj.container.on('mouseover', _onHover);
        obj.container.on('mouseout', _onMouseOut);
    };

    this.startEvent();


};

MouseScrollEvent.prototype.constructor = MouseScrollEvent;
module.exports = MouseScrollEvent;

MouseScrollEvent.prototype.onMouseScroll = function (event, delta) { };