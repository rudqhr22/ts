﻿var Interaction = {
    ClickEvent: require('./ClickEvent'),
    DragEvent: require('./DragEvent'),
    MouseScrollEvent: require('./MouseScrollEvent'),
    InputController: require('./InputController')
};


module.exports = Interaction;