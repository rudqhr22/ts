/*
 20200619 박종선
 * 한순간에 Add해야 할 때는 모아서 AddChilds, 지울 때는 RemoveChildren을 사용하길 권장
 * 추가 삭제될 때마다 sort 알고리즘 사용되기 때문
*/

var Container = require('./Container');
var Tween = require('./Tween');
/**
 * An UI Container object
 *
 * @class
 * @extends PIXI.UI.UIBase
 * @memberof PIXI.UI
 * @param desc {Boolean} Sort the list descending
 * @param tweenTime {Number} if above 0 the sort will be animated
 * @param tweenEase {PIXI.UI.Ease} ease method used for animation
 */

//사이사이의 Gap 추가
function SortableList(desc, tweenTime, tweenEase, gap) {
    Container.call(this);
    this.desc = typeof desc !== "undefined" ? desc : false;
    this.tweenTime = tweenTime || 0;
    this.tweenEase = tweenEase;
    this.gap = gap || 0;
    this.items = [];

}

SortableList.prototype = Object.create(Container.prototype);
SortableList.prototype.constructor = SortableList;
module.exports = SortableList;

SortableList.prototype.addChild = function (UIObject, fnValue, fnThenBy) {
    Container.prototype.addChild.call(this, UIObject);
    if (this.items.indexOf(UIObject) == -1) {
        this.items.push(UIObject);
    }

    if (typeof fnValue === "function")
        UIObject._sortListValue = fnValue;

    if (typeof fnThenBy === "function")
        UIObject._sortListThenByValue = fnThenBy;

    if (!UIObject._sortListRnd)
        UIObject._sortListRnd = Math.random();



    this.sort();
};

/*
 20200619 박종선
 * SortableList의 AddChild를 여러번 해야하는 상황이 왔을 때, Sort의 반복이 지나치게 많아짐
 * 한 번에 넣고 Sort하기 위한 함수 제작
*/
SortableList.prototype.addToContainer = function (UIObject, fnValue, fnThenBy) {
    Container.prototype.addChild.call(this, UIObject);
    if (this.items.indexOf(UIObject) == -1) {
        this.items.push(UIObject);
    }

    if (typeof fnValue === "function")
        UIObject._sortListValue = fnValue;

    if (typeof fnThenBy === "function")
        UIObject._sortListThenByValue = fnThenBy;

    if (!UIObject._sortListRnd)
        UIObject._sortListRnd = Math.random();
}
SortableList.prototype.addChilds = function (...childArr) {
    for (let i = 0; i < childArr.length; i++) {
        this.addToContainer(childArr[i][0], childArr[i][1], childArr[i][2]);
    }
    this.sort();

};

SortableList.prototype.removeChildren = function () {
    let c = this.children;
    for (let i = c.length - 1; i > -1; i--) {
        Container.prototype.removeChild.call(this, c[i]);
    }
    this.items = [];

}


//

SortableList.prototype.removeChild = function (UIObject) {
    if (arguments.length > 1) {
        for (var i = 0; i < arguments.length; i++) {
            this.removeChild(arguments[i]);
        }
    }
    else {
        Container.prototype.removeChild.call(this, UIObject);
        var index = this.items.indexOf(UIObject);
        if (index != -1) {
            this.items.splice(index, 1);
        }
        this.sort();
    }
};


SortableList.prototype.sort = function (instant) {
    clearTimeout(this._sortTimeout);

    if (instant) {
        this._sort();
        return;
    }

    var _this = this;
    this._sortTimeout = setTimeout(function () { _this._sort(); }, 0);
};

SortableList.prototype._sort = function () {
    var self = this,
        desc = this.desc,
        y = 0,
        alt = true;

    this.items.sort(function (a, b) {
        var res = a._sortListValue() < b._sortListValue() ? desc ? 1 : -1 :
            a._sortListValue() > b._sortListValue() ? desc ? -1 : 1 : 0;

        if (res === 0 && a._sortListThenByValue && b._sortListThenByValue) {
            res = a._sortListThenByValue() < b._sortListThenByValue() ? desc ? 1 : -1 :
                a._sortListThenByValue() > b._sortListThenByValue() ? desc ? -1 : 1 : 0;
        }
        if (res === 0) {
            res = a._sortListRnd > b._sortListRnd ? 1 :
                a._sortListRnd < b._sortListRnd ? -1 : 0;
        }
        return res;
    });

    for (var i = 0; i < this.items.length; i++) {
        var item = this.items[i];

        alt = !alt;

        if (this.tweenTime > 0) {
            Tween.fromTo(item, this.tweenTime, { x: item.x, y: item.y }, { x: 0, y: y }, this.tweenEase);
        }
        else {
            item.x = 0;
            item.y = y;
        }
        if (i !== this.items.length - 1)
            y += item.height + this.gap;
        else
            y += item.height;
        if (typeof item.altering === "function")
            item.altering(alt);
    }

    //force it to update parents when sort animation is done (prevent scrolling container bug)
    if (this.tweenTime > 0) {
        setTimeout(function () {
            self.updatesettings(false, true);
        }, this.tweenTime * 1000);
    }
};


