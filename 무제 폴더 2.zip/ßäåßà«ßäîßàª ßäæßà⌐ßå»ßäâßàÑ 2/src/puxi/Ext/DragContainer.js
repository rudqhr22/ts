import Container from '../Container';

export default class DragContainer extends Container
{
    constructor(width, height)
    {
        super(width, height);
        super.enableHitArea(true);
    }
}