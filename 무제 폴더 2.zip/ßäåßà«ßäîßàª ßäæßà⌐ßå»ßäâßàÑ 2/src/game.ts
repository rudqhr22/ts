
import { GameManager, GameManagerConfig } from "./GameManager"

var Root: Game;

export class Game extends GameManager {
    constructor(config : GameManagerConfig) {
        super(config)
        Root = this;

    }

    //protected async onEnterFrame(dt: number): Promise<void> {
    protected onEnterFrame(dt: number): void {

    }

	//protected async onInit(): Promise<void> {
    protected  onInit(): void {
        console.log('init');

    }
}



export { Root }