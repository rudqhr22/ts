import {Component,  ComponentBuilder } from "./Component";
import *as PUXI from './puxi'
import *as PIXI from 'pixi.js'


export class ImageComponent extends Component {
    private _sprite: PUXI.Sprite | null;

    constructor(builder:ImageComponentBuilder) {
        super(builder)


        this.setTexture(builder.SpritePath);
        //this._sprite.tint = builder.dtint;
        //this._sprite.alpha = builder.alpha;
        //this.addChild(this._bg)
    }

    public setTexture(texture: PIXI.Texture): void {
        if (this._sprite != null) {
            this.removeChild(this._sprite);
        }
        this._sprite = new PUXI.Sprite(PIXI.Texture.WHITE);
        this._sprite.width = "100%";
        this._sprite.height = "100%";
        this.addChild(this._sprite);
    }

}



export class ImageComponentBuilder extends ComponentBuilder {
    private _spritePath : PUXI.Sprite | null;

    public constructor() {
        super();
    }

    get SpritePath() { return this._spritePath }

    public Instantiate(): ImageComponent {
        return new ImageComponent(this);
    }

    public setTexture(texture: PIXI.Texture) : this {
        this._spritePath = texture;
        return this;
    }


}