import { Component, ComponentBuilder } from "./Component";


export class UIScene extends Component {
    constructor() { super(new ComponentBuilder().setFit()) }


}