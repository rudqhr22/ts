import *as PIXI from "pixi.js";
import *as PUXI from "../src/puxi";

export class Component extends PUXI.Container {
    private  _isInitiated = false;

    [x: string]: any;
    constructor(builder : ComponentBuilder = new ComponentBuilder()) {
        super();

        this.x = builder.x;
        this.y = builder.y;

        this.pivotX = builder.pivotX;
        this.pivotY = builder.pivotY;
        this.width = builder.w;
        this.height = builder.h;
        if (builder.parent != null) { builder.parent.addChild(this); }
    }

    public enterFrame(dt: number): void {
        if (!this._isInitiated) {
            this._isInitiated = true;
            this.onStart();
        }

        this.onEnterFrame(dt);
        this.children.forEach(child => {
            if (child instanceof Component) {
                child.enterFrame(dt);
            }
        });
    }

    protected onStart(): void { };
    protected onEnterFrame(dt: number): void { };
    protected onDestroy(): void { };
}

export class ComponentBuilder {
    private _x : number | string = 0;
    private _y : number | string = 0;
    private _w : number | string = 200;
    private _h : number | string = 200;
    private _pivotX : number = 0;
    private _pivotY : number = 0;
    private _parent: Component | PIXI.Container | null = null;
    constructor() {}

    public get x() { return this._x; }
    public get y() { return this._y; }
    public get w() { return this._w; }
    public get h() { return this._h; }
    public get pivotX() { return this._pivotX; }
    public get pivotY() { return this._pivotY; }
    public get parent() { return this._parent; }

    public setPivot(x: number,  y: number): this {
        this._pivotX = x;
        this._pivotY = y;
        return this;
    }

    public setSize(width: number | string, height: number | string): this {
        this._w = width;
        this._h = height;
        return this;
    }

    public addTo(parent: Component | PIXI.Container): this {
        this._parent = parent;
        return this;
    }

    public setPosition(x: number | string, y: number | string): this {
        this._x = x;
        this._y = y;
        return this;
    }

    public setFit(): this {
        this.setSize("100%", "100%")
        .setPivot(0.0, 0.0)
        .setPosition(0, 0)
        return this;
    }
    public Instantiate(): Component {
        return new Component(this);
    }
}