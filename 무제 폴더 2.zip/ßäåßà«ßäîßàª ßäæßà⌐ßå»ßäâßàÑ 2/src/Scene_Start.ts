import { ImageComponent, ImageComponentBuilder } from "./ImageComponent";
import { UIScene } from "./UIScene";
import *as PIXI from "pixi.js";
import *as PUXI from "./puxi";
import { Root } from "./game";

export default class Scene_start extends UIScene {
    constructor() {super()}

    public onStart() {

        console.log('scenestart')

        let b = new ImageComponentBuilder()
            .setTexture(PIXI.Texture.WHITE)
            .setSize(200, 200)
            .setPosition(0,0)
            .addTo(this)
            .Instantiate();

        // let a = new PUXI.Sprite(PIXI.Texture.WHITE);
        // a.width = 100
        // a.height = 100
        // this.addChild(a);

    }
}